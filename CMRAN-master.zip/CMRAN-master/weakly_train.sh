python weakly_main.py \
--gpu 0 \
--lr 0.0005 \
--snapshot_pref "./Exps/WeaklySupv/exp1/ "\
--n_epoch 200 \
