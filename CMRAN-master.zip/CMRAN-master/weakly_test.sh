python weakly_main.py \
--gpu 6 \
--resume "/home/xuhaoming/Projects/AVE-workspace/release_workspace/code_to_be_released/VGG-72.94/code/weaksupv-best/Exps/WeaklySupv/Weakly-NewCode-666-4-head-Inter2Head-LR5-20-40-0.5-cp0.5/model_epoch_39_top1_72.363_task_Supervised_best_model.pth.tar" \
--evaluate \
--print_freq 1
