s = "abcabcbb"
l = list(s)
b = []
a = []
if l == []:
    print(0)
else:
    num = 0
    i = 0
    while i < len(l):
        if i == len(l)-1:
            pass
        else:
            if  l[i] == l [i+1]:
                num = 1
            else:
                b.append(num)

                if l[i] in a :
                    num = 1
                    a = []
                else:
                    num = num + 1
                    a.append(l[i])
        i=i+1
    print(max(b))


'''
class ListNode:
     def __init__(self, val=0, next=None):
         self.val = val
         self.next = next
head = [1,2,3,4,5]

def middleNode(self, head: ListNode) -> ListNode:
        return head
A=[middleNode]
print(A[-1])
print(A[-1].next)

nums = [1,2,3,4,5,6,7]
k = 3
b = nums[:]
n = len(b)
for i in range(0, k):
    if n>1
        nums.remove (nums[-1])
    nums.insert(0, b[-1])
    b.remove(b[-1])

print(nums)
'''
