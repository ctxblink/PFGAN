python supv_main.py \
--gpu 1 \
--lr 0.0004 \
--clip_gradient 0.1 \
--snapshot_pref "./Exps/Supv/exp710/" \
--n_epoch 100 \
--print_freq 1 \
--resume "./Exps/Supv/exp620/model_epoch_16_top1_77.488_task_Supervised_best_model.pth.tar"
