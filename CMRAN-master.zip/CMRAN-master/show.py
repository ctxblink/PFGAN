import torch
import os
import torchvision
# 加载模型
from model.main_model_m import weak_main_model as main_model


#model = torch.load('model_epoch_16_top1_77.488_task_Supervised_best_model.pth.tar', map_location='cpu')
v_shape =torch.rand (32, 10, 7, 7,256)  # 不影响模型
a_shape = torch.rand(32, 10,128)

model = main_model()
checkpoint = torch.load(r"./Exps/WeaklySupv/exp923wme/model_epoch_21_top1_72.910_task_Supervised_best_model.pth.tar")
model.load_state_dict(checkpoint)
model.cuda()
model.eval()

# 向模型中输入数据以得到模型参数
traced_script_module = torch.jit.trace(model, v_shape,a_shape)

# 保存模型
traced_script_module.save("torch_script_eval.pt")
