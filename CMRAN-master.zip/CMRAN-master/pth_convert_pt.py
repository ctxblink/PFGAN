import torch
from main_model import supv_main_model as main_model
import numpy as np

model = main_model()
#state_dict = torch.load('./model_epoch_40_top1_78.458_task_Supervised_best_model.pth.tar')
state_dict = torch.load('/home/data1_4t/ctx/ctx_project/CMRAN-master/Exps/Supv/exp2/model_epoch_175_top1_76.841_task_Supervised_best_model.pth.tar')
#state_dict = {k:torch.DoubleTensor(v) for k, v in state_dict.items()}

model.load_state_dict(state_dict,False)
model.eval()

v = torch.rand(1,10,7,7,512)
#v = np.zeros((1,10,7,7,512))
#v = torch.from_numpy(v)
#v = v.type(torch.FloatTensor)
v = v.cuda()
#a = np.zeros((1,10,128))
a = torch.rand(1,10,128)
#a = a.type(torch.FloatTensor)
#a = torch.from_numpy(a)
a = a.cuda()
ts = torch.jit.trace(model.cuda(),(v,a))

ts.save("cmra.pt")