import cv2
import gb
import os

def preprocessing():
    print("开始获取数据...")
    datasetDir ='/home/data1_4t/ctx/blackpink/0cKUAJ9rr0M'
    img_path = gb.glob(os.path.join(datasetDir, '*.mp4'))
    rawImgs = []
    opImgs = []
    for i, curFrame in enumerate(img_path):
        print("curFrame: ", curFrame)
        img = cv2.imread(curFrame)
        font = cv2.FONT_HERSHEY_SIMPLEX  # 使用默认字体
        img = cv2.putText(img, str(i+1), (0, 20), font, 0.8, (255, 255, 255), 1)  # #添加文字，1.2表示字体大小，（0,40）是初始的位置，(255,255,255)表示颜色，2表示粗细
        cv2.namedWindow("rawImageFrame", 0)
        cv2.resizeWindow("rawImageFrame", 360, 240)
        cv2.imshow('rawImageFrame', img)
        cv2.waitKey(30)
    cv2.destroyAllWindows()

preprocessing()

ffmpeg -i 0cKUAJ9rr0M.mp4 -vf "drawtext=fontfile=simhei.ttf: text='Ukulele':x=10:y=10:fontsize=24:fontcolor=white:shadowy=2" one.mp4
ffmpeg -re -i 0cKUAJ9rr0M.mp4 -vf "drawtext=fontfile=simhei.ttf: text='helloworld':x=10:y=10:fontsize=50:fontcolor=white:shadowy=2" -f flv rtmp://127.0.0.1:1935/live/123




'''
import os
os.environ["IMAGEIO_FFMPEG_EXE"] = "/usr/bin/ffmpeg"
from moviepy.editor import *
from moviepy.video.VideoClip import TextClip


video = VideoFileClip("/home/data1_4t/ctx/blackpink/0cKUAJ9rr0M.mp4").subclip(4,10)

txt_clip = (TextClip("Ukulele",fontsize=70,color='red')
             .set_position('center')#水印内容居中
             .set_duration(6))

result = CompositeVideoClip([video, txt_clip])
result.write_videofile("two.mp4",fps=25)
'''





