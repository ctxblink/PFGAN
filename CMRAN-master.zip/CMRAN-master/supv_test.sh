python supv_main.py \
--gpu 6 \
--resume "./Exps/Supv/Superivsed-Interaction-Ours-456-4-head-BCELogits-LR10-20-30-0.1/model_epoch_12_top1_76.095_task_Supervised_best_model.pth.tar" \
--evaluate \
--print_freq 1
